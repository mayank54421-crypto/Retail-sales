# Retail Sales Analysis and Prediction Project

## How to run
1. Install Python and Jupyter Notebook, or open Google Colab.
2. Open `Retail_Sales_Analysis_and_Prediction.ipynb`.
3. Run the cells from top to bottom.
4. Optional: put a genuine Sample Superstore CSV beside the notebook and name it `SampleSuperstore.csv`.
5. If the CSV is absent, the notebook uses clearly labeled synthetic practice data.

## Install packages
In a notebook cell:
```python
%pip install pandas numpy matplotlib seaborn scikit-learn
```

## Important
The fallback dataset is synthetic and only helps demonstrate the workflow. For a real-world submission, use a real dataset, cite its source, and base the report conclusions on the results generated from that dataset.
